# NUS_CS5228_Project  
This is the source code for CS5228 project (AY 2019/2020 Semester 2)   
Winning 1st place at NUS CS5228 in-class Kaggle competition 2020!
## Folder Structure
- src  
	Solution(jupyter notebook)  
- kaggle_submission  
	Final Kaggle submissions  
- doc  
	Kaggle competition report 
## [Task](https://www.kaggle.com/c/cs5228)
https://www.kaggle.com/c/cs5228  
Kaggle Team: Exceed50k
## Contributor  
[XiangPan](https://github.com/Xiang-Pan)  
[Yihao](https://github.com/Vincentwei1021)  
[ZhuQinglei](https://github.com/ZhuQinglei)

## [Google Docs](https://docs.google.com/document/d/1W6jIvFtX8nyxv8nMnLYfKLoAtyhfCOEJm2UM9hVqRqk/edit?usp=sharing)  


